package com.nzue.avauserapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
