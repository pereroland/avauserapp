import 'package:flutter/material.dart';

String success_status = "200";
String unauthorized_status = "401";
String expire_token_status = "408";
String data_not_found_status = "404";
String already_login_status = "205";
String already_added_in_cart = "206";
