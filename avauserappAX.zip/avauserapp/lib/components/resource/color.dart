import 'dart:ui';

class AppColor {
  final mainColorLight = Color(0xffF1C40E);
  final mainColorDark = Color(0xff102B46);
}
