class Images {
  final welcomeScreen = "Images/welcomeScreen.png";
  final welcomefirst = "Images/welcomefirst.png";
  final welcomesecond = "Images/welcomesecond.png";
  final introcurvefirst = "Images/introcurvefirst.png";
  final imagecurvesecond = "Images/introcurvesecond.png";
  final imagecurvethree = "Images/introcurvethree.png";
  final loginsignuppage = "Images/loginsignuppage.png";
  final bottomloginsignup = "Images/bottomloginsignup.png";

  final trainerAdityaKhobragade = "image/trainer/trainer_aditya_khobragade.png";
  final trainerAnnMathewys = "image/trainer/trainer_ann_mathewys.png";
  final trainerAshishChutake = "image/trainer/trainer_ashish_chutake.png";
  final trainerAshishChutake2 = "image/trainer/trainer_ashish_chutake2.png";
  final trainerAshishChutake3 = "image/trainer/trainer_ashish_chutake3.png";
  final trainerDarshanBarapatre = "image/trainer/trainer_darshan_barapatre.png";
  final trainerLaitKalambe = "image/trainer/trainer_lait_kalambe.png";

  const Images();
}
