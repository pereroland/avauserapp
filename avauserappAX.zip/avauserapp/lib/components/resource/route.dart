class RoutePath {
  static const String splash = "/";
  static const String onBoarding = "/on-boarding";
  static const String home = "/home";
  static const String healthTipDetail = "/health-tip-detail";
  static const String exerciseGroup = "/excercuse-group";
  static const String exerciseDetail = "/excercuse-detail";
  static const String trainerDetail = "/trainer-detail";
}
