library constants;
import 'dart:ui';

const String SUCCESS_MESSAGE=" You will be contacted by us very soon.";
const PrimaryColor =  Color(0xFF453885);